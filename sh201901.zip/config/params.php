<?php

return [
    'adminEmail' => 'seltor@mail.ru',
];
