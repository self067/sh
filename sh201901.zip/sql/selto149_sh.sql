CREATE SCHEMA `selto149_sh` DEFAULT CHARACTER SET utf8 ;

ALTER TABLE `selto149_sh`.`good` 
RENAME TO  `selto149_sh`.`product` ;


